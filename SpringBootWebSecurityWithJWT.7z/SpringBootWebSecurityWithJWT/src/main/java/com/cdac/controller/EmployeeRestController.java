package com.cdac.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

@RestController
@RequestMapping(path="employees")
public class EmployeeRestController {
	@Autowired
	private EmployeeService service;
	
	//GET -> http://localhost:9090/EmployeeApp/employees
	@RequestMapping(method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> getAllEmployees(){
		List<Employee> list = service.findAllEmployeesWithAddress();
		return list;
	}
	
	// GET -> http://localhost:9090/EmployeeApp/employees/100
	@RequestMapping(path="{id}", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public Employee getEmployeeById(@PathVariable("id") Integer employeeId) {
		Employee result = service.findEmployeeById(employeeId);
		if(result != null) {
			return result;
		}else {
			return null;
		}
	}
	//POST -> http://localhost:9090/EmployeeApp/employees
	@RequestMapping(method=RequestMethod.POST)
	public ResponseEntity<String> addEmployee(@RequestBody Employee employee) {
		boolean result = service.addEmployee(employee);
		ResponseEntity<String> responseEntity = null;
		if(result) {
			responseEntity = new ResponseEntity<String>("Employee with employee id="+employee.getEmployeeId()+" is added.", HttpStatus.CREATED);
		}else {
			responseEntity = new ResponseEntity<String>("Employee with employee id="+employee.getEmployeeId()+" is not added.", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	// DELETE -> http://localhost:9090/EmployeeApp/employees/100
	@RequestMapping(path="{id}", method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteEmployee(@PathVariable("id") int employeeId) {
		boolean result = service.removeEmployee(employeeId);
		ResponseEntity<String> responseEntity = null;
		if(result) {
			responseEntity = new ResponseEntity<String>("Employee with employee id="+employeeId+" is deleted.", HttpStatus.OK);
		}else {
			responseEntity = new ResponseEntity<String>("Employee with employee id="+employeeId+" is not deleted.", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	//PUT -> http://localhost:9090/EmployeeApp/employees
		@RequestMapping(method=RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<String> updateEmployee(@RequestBody Employee employee) {
			boolean result = service.modifyEmployee(employee);
			ResponseEntity<String> responseEntity = null;
			if(result) {
				responseEntity = new ResponseEntity<String>("Employee with employee id="+employee.getEmployeeId()+" is updated.", HttpStatus.CREATED);
			}else {
				responseEntity = new ResponseEntity<String>("Employee with employee id="+employee.getEmployeeId()+" is not updated.", HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return responseEntity;
		}
}








