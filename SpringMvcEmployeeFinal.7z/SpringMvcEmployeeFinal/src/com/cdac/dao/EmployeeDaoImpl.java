package com.cdac.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.cdac.model.Employee;
import com.cdac.utils.JpaUtils;
@Repository//("dao")
public class EmployeeDaoImpl implements EmployeeDao{
	private EntityManager entityManager;
	
	public EmployeeDaoImpl() {
		
	}
	public int createEmployee(Employee employee) {
		entityManager = JpaUtils.getEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(employee);
		entityManager.getTransaction().commit();
		return 1;
	}
	public Employee readEmployeeById(int employeeId) {
		entityManager = JpaUtils.getEntityManager();
		Employee employee = entityManager.find(Employee.class, employeeId);
		return employee;
	}
	public List<Employee> readAllEmployee() {
		return null;
	}
	public int updateEmployee(Employee employee) {
		entityManager = JpaUtils.getEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(employee);
		entityManager.getTransaction().commit();
		return 1;
	}
	public int deleteEmployee(int employeeId) {
		entityManager = JpaUtils.getEntityManager();
		entityManager.getTransaction().begin();
		Employee employee = readEmployeeById(employeeId);
		entityManager.remove(employee);
		entityManager.getTransaction().commit();
		return 1;
	}
}
